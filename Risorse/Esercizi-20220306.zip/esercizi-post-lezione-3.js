// Usando un ciclo for loggare in console i quadrato di ogni numero
// Il codice deve funzionare con array di qualsiasi dimensione
// per ottenere la dimensione dell'array usasare la prorpieta length dell array

let numeri = [2, 4, 54, 66, 78, 99, 102]

